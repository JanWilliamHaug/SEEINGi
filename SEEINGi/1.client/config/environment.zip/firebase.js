// firebase.js
import * as firebase from "firebase";

firebase.initializeApp({
  apiKey: "AIzaSyBBB6ubBLnyf7f0gQx-HsGe4s3AXF8AxM8",
  authDomain: "https://seeingi-67994.firebaseapp.com/",
  databaseURL: "https://seeingi-67994-default-rtdb.firebaseio.com/",
  projectId: "seeingi-67994",
  storageBucket:
    "https://console.firebase.google.com/project/seeingi-67994/storage/seeingi-67994.appspot.com/files",
  messagingSenderId: "527033943156",
});

export default firebase;
